
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.3.0'
version = '1.3.0'
full_version = '1.3.0'
git_revision = 'e1e44d12637997606b1bcc0c6de232349e11eee0'
release = True

if not release:
    version = full_version
